const { initializeApp } = require('firebase/app');
const { getFirestore } = require('firebase/firestore');
const { getStorage } = require('firebase/storage');

const firebaseConfig = {
  apiKey: "AIzaSyA-Vwc7wzpamsIflTWOWu_u_NXbKFEfdm0",
  authDomain: "fbsg-fd09a.firebaseapp.com",
  projectId: "fbsg-fd09a",
  storageBucket: "fbsg-fd09a.firebasestorage.app",
  messagingSenderId: "731894584001",
  appId: "1:731894584001:web:af865d8357caaacac83a40",
  measurementId: "G-6E5PGKY52C"
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);
const storage = getStorage(app); 

module.exports = { db, storage };
